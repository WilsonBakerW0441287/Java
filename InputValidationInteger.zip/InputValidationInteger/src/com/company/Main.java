package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Scanner sc = new Scanner(System.in);
        int theNum = 0;
        System.out.println("Enter an integer value: ");
        if (sc.hasNextInt()) { //Check if the value is an integer or not
            // if true, run the code in this IF to get teh value from scanner and assign it to
            // the variable theNum

            int  myNum = sc.nextInt();
            System.out.println("This is an intege input");
            theNum = myNum;
        }
        System.out.println("the value is : "+ theNum);
        String key1 = null;
        System.out.println("press any key to continue : ");
        key1 = sc.nextLine();sc.nextLine();
        // Second validation
        //Try Catch method
        System.out.println("Try Catch Method");
        System.out.println("=".repeat(30));
        String myInput = "12";
        //        try {
//            int myInt = Integer.parseInt(myInput) ;
//            System.out.println("This is correct integer input for "+myInt);
//        } catch (NumberFormatException ex) {
//            System.out.println("Try again; type mismatch");
//        }
        try {
            System.out.println("Enter an integer value");

            int myInt = Integer.parseInt(sc.nextLine());
            System.out.println("This is a correct integer input for "+myInt);
        } catch (NumberFormatException ex) {
            System.out.println("Try again; type mismatch");
        }






    }
}
