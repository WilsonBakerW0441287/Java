package com.company;

public class Cow {
}
