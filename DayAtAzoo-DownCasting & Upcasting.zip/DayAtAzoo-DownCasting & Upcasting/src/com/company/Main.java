package com.company;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
	// write your code here
//        Animal myDog = new Animal();
//        Animal myCat = new Animal("Cat",25,"Home",false);
//        Animal myCow = new Animal("Cow",1000,"Farm",false);
//        Animal myLion = new Animal("Lion",1100,"Jungle",true);
//        System.out.println(myCat);
//        System.out.println(myLion.toString());
//        System.out.println(myCow);
//        System.out.println(myLion.toString());
////        Step 7:
////        Add the three Animals to the Zoo(Object Array).
//        ArrayList<Animal> animalList = new ArrayList<Animal>();
//        animalList.add(myCat);
//        animalList.add(myLion);
//        animalList.add(myCow);
//        animalList.add(myDog);
////        Step 8:
////        Let’s interact with our objects, to test their functionality.
////        Create a loop to take each Animal out of the Zoo and call its methods.
//        System.out.println("From foreach");
//        for (Animal myAnimal:animalList) {
//            System.out.println(myAnimal.makeSound());
//            System.out.println(myAnimal.feedAnimal());
//            System.out.println(myAnimal.toString());
//        }
        Cat myCat = new Cat("Cat",30,"Home",false,6);
        System.out.println(myCat.makeSound());
        System.out.println(myCat.feedAnimal("Milk"));
        System.out.println(myCat.toString());
        Shark myShark = new Shark("Shark",2500,"Ocean",true,"Atlantic");
        ArrayList<Animal> animalList = new ArrayList<>();
        animalList.add(myCat);
        animalList.add(myShark);
        System.out.println("From for each");
        int count = 0;
        for (Animal myAnimal:animalList) {
            System.out.println("Iteration # " + count++);
            System.out.println(myAnimal.toString());
            System.out.println(myAnimal.makeSound());
            //Down casting
            System.out.println("Down Casting");
            Cat currentCat = (Cat) myAnimal;
            System.out.println(currentCat.feedAnimal("Mouse"));
            System.out.println(currentCat.makeSound());
        }
        Animal myUnspecifiedAnimal = new Animal("Cat",13000,"Don't Know",false);
        //Please fix the following two statements by applying either downcasting or upcastiong.
        System.out.println(myUnspecifiedAnimal.makeSound());
        System.out.println(myUnspecifiedAnimal.feedAnimal());
        //The following is Upcasting
        System.out.println("Up Casting");
        Animal myUnspecifiedAnimal2 = new Cat("Cat",13000,"Don't Know",false,7);
        System.out.println(myUnspecifiedAnimal2.makeSound());
    }
}
