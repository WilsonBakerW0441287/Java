package com.company;

public class Cow extends Animal {
    private int UtterCount;
    public Cow(String pSpecies, double pMaxWeight, String pHabitat, boolean pIsEndangered, int pUtterCount){
        super(pSpecies, pMaxWeight,  pHabitat, pIsEndangered);
        this.UtterCount =pUtterCount;    }
    public String makeSound(){
        return String.format("A %s can make a MOO sound!",this.getSpecies());    }
    public String toString(){
        return super.toString() + String.format(" This cow has %d utters",UtterCount);
    }
    public String feedAnimal(String food){
        return String.format("Feed a %s the %s",super.getSpecies(),food );
    }
}
