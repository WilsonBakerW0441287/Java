package com.company;

public class  Dog extends Animal {

    public String makeSound(){
//        String sound = "";
//
//        return String.format("A %s make a %s sound",this.species,sound);
        return "WoofWoof";
    }


}
