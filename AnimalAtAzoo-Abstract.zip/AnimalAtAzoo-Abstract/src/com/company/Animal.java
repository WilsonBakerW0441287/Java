package com.company;

public abstract class Animal {
//    Step1:
//    Define Animal Class with four properties:
//            1. Species -ex. Lion, cow or anything else.
//            2. Max Weight – The maximum average weight of an adult of the species.
//            3. Habitat – ex. Jungle, ocean, or mountain, … etc.
//4. Is Endangered- Flag to indicate whether the animal species is endangered.
    private String species;
    private double maxWeight;
    private String habitat;
    private boolean isEndangered;

//    Step2:
//    Add a user defined constructor without parameters constructor,
//    with any default values that you feel be required.
    public Animal(){

        this.species = "Dog";
        this.setMaxWeight(40);
        this.setHabitat("Home");
        this.setEndangered(false);
    }
//    Step3:
//    Add a parametrized constructor to allow setting of all properties on object creation.
    public Animal(String pSpecies, double pMaxWeight, String pHabitat, boolean pIsEndangered){
        this.setSpecies(pSpecies);
//        this.species = pSpecies;
        this.setMaxWeight(pMaxWeight);
        this.setHabitat(pHabitat);
        this.setEndangered(pIsEndangered);
    }


//    Step4:
//    Determine scope/access of properties:
//            - Are they completely internal to the class?=====> private
//            - should an external class be permitted to read the property values?==>public
//            - should an external class be permitted to change the property values?=====>public
    //It is done.

//    Step 5:
//    Create appropriate Getter/Setter methods, as required.
public String getSpecies() {
    return species;
}

    public void setSpecies(String species) {
        this.species = species;
    }

    public double getMaxWeight() {
        return maxWeight;
    }

    public void setMaxWeight(double maxWeight) {
        this.maxWeight = maxWeight;
    }

    public String getHabitat() {
        return habitat;
    }

    public void setHabitat(String habitat) {
        this.habitat = habitat;
    }

    public boolean isEndangered() {
        return isEndangered;
    }

    public void setEndangered(boolean endangered) {
        isEndangered = endangered;
    }
//    Step 6:
//    Create three methods, i.e., actions that Animal instances can do, or that involve Animal objects.
//          - Animal can be fed-ex. Feed a Tiger a Steak.
//          - Animal can make sound-ex. A Cow can “moo”.
//         - In our program, an animal can report its state. (Use toString()):
//            *. Ex., “I am a 500Ib tiger that lives in the jungle. I am an Endangered species.”
//    - Note: Let’s do all console printing in Main(), not in  Animal.
    public String feedAnimal(){
        return "Feed a "+this.species + "a Steak";
    }
    //If you are goimg to abstract any existing method
    //You have to declare this method only (USing the mehod signature)
    //and without any implementation(No curly brackets)
    public abstract String makeSound();//I don't want to use this method as long as the Animal class is abstracted.
    public String toString(){
        String animalStatus = "not Endangered";
        if (this.isEndangered){
            animalStatus = "Endangered";
        }
        return String.format("I am a %.2f Ib %s that lives in the %s. I am %s species.",
               this.maxWeight, this.species,this.habitat,animalStatus);
    }















}
