package com.company;

public class Food {

    String name;

    Food(String name){
        this.name = name;
    }
}