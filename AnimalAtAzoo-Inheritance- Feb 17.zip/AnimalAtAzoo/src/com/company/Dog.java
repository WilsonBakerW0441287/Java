package com.company;

public class Dog {


}
