package com.company;

public class Cat extends Animal {
    // Extends means that :
    //Cat  class is a child/subclass of Animal class.
    //Cat class cad do the following:
    //1. It will use the Animal properties.
    //2. It will use all of the existing methods, getters & setters

    //Those are my own properties:
    private int whiskersLength;

    //Constructor
    public Cat(String pSpecies, double pMaxWeight, String pHabitat, boolean pIsEndangered,
               int pWhiskersLength ){
        super(pSpecies,pMaxWeight,pHabitat,pIsEndangered);
        this.whiskersLength=pWhiskersLength;
    }

    public String makeSound(){
//        return String.format("A %s can make a Meow sound",this.getSpecies());
        return String.format("A %s can make a Meow sound",super.getSpecies());
    }
    public String toString(){
        return super.toString() + String.format(" Whiskers length is %d CM",this.whiskersLength);
    }


}
