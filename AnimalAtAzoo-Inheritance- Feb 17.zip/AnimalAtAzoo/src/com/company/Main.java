package com.company;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
	// write your code here
//        Animal myDog = new Animal();
//        Animal myCow = new Animal("Cow",2000,"Farm",false);
//        Animal myCat = new Animal("Cat",30,"Home",false);
//        Animal myLion = new Animal("lION",1000,"Jungle",true);
//        System.out.println(myCat);
//        System.out.println(myCat.toString());
//        System.out.println(myLion.toString());
////        Step 7:
////        Add the three Animals to the Zoo(Object Array).
//        ArrayList<Animal> animalList = new ArrayList<>();
//        animalList.add(myCat);
//        animalList.add(myLion);
//        animalList.add(myCow);
//        animalList.add(myDog);
////        Step 8:
////        Let’s interact with our objects, to test their functionality.
////        Create a loop to take each Animal out of the Zoo and call its methods.
//        System.out.println("From foreach");
//        for (Animal myAnimal:animalList) {
//            System.out.println(myAnimal.feedAnimal());
//            System.out.println(myAnimal.makeSound());
//            System.out.println(myAnimal.toString());
//
//        }
        Cat myCat = new Cat("Cat",30,"Home",false,5);
        System.out.println(myCat.makeSound());
        System.out.println(myCat.toString());
        Cow myCow = new Cow("Cow",2000,"Farm",false,4);
        System.out.println(myCow.makeSound());
        System.out.println(myCow.toString());
        System.out.println(myCow.feedAnimal("Grass"));
        ArrayList<Animal> animalList = new ArrayList<>();
        animalList.add(myCat);
        animalList.add(myCow);

        System.out.println("From for each");
        for (Animal myAnimal:animalList) {
            System.out.println(myAnimal.makeSound());
            System.out.println(myAnimal.toString());

        }





    }
}
