package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code

        Circle mycircle = new Circle();
        Circle myothercircle = new Circle();
        Circle myLastCircle = new Circle();

        mycircle.toString();
        myothercircle.setRadius(2);
        myothercircle.toString();
        myLastCircle.setRadius(3);
        myLastCircle.setColour("blue");
        myLastCircle.toString();


    }
}
