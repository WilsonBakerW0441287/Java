package com.company;


public class Circle {
    private int radius;
    private String colour;

    public int getRadius() {
        return radius;
    }

    public void setRadius(int radius) {
        this.radius = radius;
    }

    public String getColour() {
        return colour;
    }

    public void setColour(String colour) {
        this.colour = colour;
    }

    public Circle() {
        this.colour = "green";
        this.radius = 2;
    }

    public Circle(int radius) {
        this.radius = radius;
    }

    public Circle(String colour, int radius) {
        this.colour = colour;
        this.radius = radius;
    }

    public void getArea(int radius) {
        double totalArea, pie;
        pie = 3.14152967;
        totalArea = pie * (radius * 2);
        System.out.println("The total area is: " + totalArea);
    }

    public String toString() {
        String reports = String.format("Radius = %d  Colour = %s", this.radius, this.colour);
        return reports;
    }

}
