package com.company;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Animal myDog = new Animal();
        Animal myCow = new Animal("Cow", 300, "Farm", false);
        Animal myCat = new Animal("cat", 30, "Home", false);
        Animal myLion = new Animal("Lion", 1000, "Jungle", true);
        System.out.println(myCat);
        System.out.println(myLion.toString());

        ArrayList<Animal> animalList = new ArrayList<>();
        animalList.add(myCat);
        animalList.add(myCow);
        animalList.add(myLion);
        animalList.add(myDog);
        System.out.println("from Foreach");
        for (Animal myAnimal : animalList) {
            System.out.println( myAnimal.feedAnimal());
            System.out.println( myAnimal.makesound());
            System.out.println(myAnimal.toString());
        }
    }
}
