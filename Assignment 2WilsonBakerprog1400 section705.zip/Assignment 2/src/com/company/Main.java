package com.company;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        int goals;
        int assists;
        String input;
        String pname;
        String playerInfo;
        String currteam;
        int teamTotalGoals;
        int teamTotalAssits;
        String nameOfTeam;
        //decalre vairables

        //inputs
        Scanner sc = new Scanner(System.in);

        //array/ objects
        ArrayList<Team> allTeams = new ArrayList<>();
        Team team1 = new Team();
        Team team2 = new Team();
        Team team3 = new Team();
        allTeams.add(team1);
        allTeams.add(team2);
        allTeams.add(team3);
        //hard coded but can be made modular


        System.out.println("FANTASY HOCKET APPLICATION\nTEAM ENTRY");
        //title
        //could make a question "how many teams?"
        for (int i = 0; i < 3; i++) { // how many teams do we want
            do {
                System.out.printf("Enter Team Name #%d: \n", (i + 1));
                while (!sc.hasNextLine()) { //While the scanner has no next line
                    System.out.println("Please enter a valid word!");
                    sc.next();
                }
                input = sc.nextLine();
            } while (input == null || input.equals(""));
            allTeams.get(i).setTeamName(input);//sets name for team object of (i) #
        }

        System.out.println("PLAYER ENTRY\n" + ("=".repeat(30)));

        for (int i = 0; i < 3; i++) { // This is for how many teams //can just as easily say (length of teamarray)
            currteam = allTeams.get(i).getTeamName();
            System.out.println("\nEnter player info for " + currteam + ": ");

            ArrayList<Players> allPlayers = new ArrayList<>();
            // loop initalized here to reset after each loop so we can | it into the teams array list array list\

            for (int j = 0; j < 4; j++) { // This is for how many players
                //give me TEAMNAME
                // player name
                // player goals
                // player assists
                //repeat 4 times ( for each player)
                //repeat all 3 times (for each team)
                //ask for name seems to repeat on second run through
                do {
                    System.out.printf("Enter name for player #%d: \n", (j + 1));
                    pname = sc.nextLine(); // we need to access the name
                    //add to players list
                }while (pname.length() < 3);
                do {
                    System.out.printf("Enter number of goals for %s: \n", pname);
                    while (!sc.hasNextInt()) { //Check that the value is an integer
                        System.out.println("Enter a positive integer number.");
                        sc.nextLine();
                    }
                    goals = sc.nextInt();
                } while (goals < 0);
                //add to players goals
                do {
                    System.out.printf("Enter number of assists for %s: \n", pname);
                    while (!sc.hasNextInt()) { //Check that the value is an integer
                        System.out.println("Enter a positive integer number.");
                        sc.nextLine();
                    }
                    assists = sc.nextInt();
                } while (assists < 0);
                sc.nextLine();
                //add player assists
                //add all to player list
                // add the list to the teams player list
                allPlayers.add(new Players(pname, goals, assists));
                allTeams.get(i).setPlayerList(allPlayers);
            }


        }
        System.out.println("REPORT STATS PER TEAM\n" + ("=".repeat(30)));

        for (Team currentTeam : allTeams) {
            System.out.println(currentTeam.teamReport());
        }// access the methods of the object team to print report
        //for each loops are insane

        System.out.println("REPORT STATS PER Player");
        System.out.println("=".repeat(30));
        //
        for (Team currentTeam : allTeams) {
            for (Players playerlist : currentTeam.getPlayerList()) {
          //using the currentTeam/playerlist variable name we access the position for what we are looking for
                System.out.println(playerlist.Playersinfo());

            }
        }


    }
}
