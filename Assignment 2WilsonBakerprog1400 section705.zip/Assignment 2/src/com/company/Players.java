package com.company;

public class Players {
    private String playername;
    private int goals;
    private int assists;
    public int total;

    public String getPlayername() {
        return playername;
    }

    public void setPlayername(String playername) {
        this.playername = playername;
    }

    public Players(String playername, int goals, int assists) {
        this.setPlayername(playername);
        this.setAssists(assists);
        this.setGoals(goals);
    }

    public int getGoals() {
        return goals;
    }

    public void setGoals(int goals) {
        this.goals = goals;
    }

    public int getAssists() {
        return assists;
    }

    public void setAssists(int assists) {
        this.assists = assists;
    }


    public String Playersinfo() {
        total = assists + goals;
        return String.format("%s:\tG - %d\tA - %d\tTotal - %d", this.playername, this.goals, this.assists, total);
    }



}