package com.company;

import java.util.ArrayList;

public class Team{
    private double budget;
    private String teamName;
    private int goalsTeam;
    private int assistsTeam;
    private int totalTeam;
    private String classrating;

    private ArrayList<Players> playerList;

    public String getTeamName() {
        return teamName;
    }

    public void setTeamName(String teamName) {
        this.teamName = teamName;
    }

    public double getBudget() {
        return budget;
    }

    public void setBudget(double budget) {
        this.budget = budget;
    }

    public ArrayList<Players> getPlayerList() {
        return playerList;
    }

    public void setPlayerList(ArrayList<Players> playerList) {
        this.playerList = playerList;
    }

    public int getGoalsTeam() {
        return goalsTeam;
    }

    public void setGoalsTeam(int goalsTeam) {
        this.goalsTeam = goalsTeam;
    }

    public int getAssistsTeam() {
        return assistsTeam;
    }

    public void setAssistsTeam(int assistsTeam) {
        this.assistsTeam = assistsTeam;
    }

    public int getTotalTeam() {
        return totalTeam;
    }

    public void setTotalTeam(int totalTeam) {
        this.totalTeam = totalTeam;
    }

    //we need to access the things inside player from the team report
    //the arraylist lets us "go into" players to get the information
    public String teamReport() {
        for (Players player : this.playerList){
            //get totals for each time
            this.goalsTeam += player.getGoals();
            this.assistsTeam += player.getAssists();
            this.totalTeam += this.goalsTeam + this.assistsTeam;
        }
                if(totalTeam > 30) {
                    this.classrating = "CLASS A";
                }
                else if (totalTeam >= 20  && totalTeam < 30) {
                    this.classrating = "CLASS B";
                }
                else if (totalTeam > 0  && totalTeam < 20) {
                    this.classrating = "CLASS C";
                }
                else if (totalTeam == 0) {
                    this.classrating = "CLASS D";
                }

                this.budget = Math.random() * 100000;

        return String.format("%s:\tG - %d\tA - %d\tTotal - %d\tBudget - $%.2f\nRating - %s",
                this.teamName, this.goalsTeam, this.assistsTeam, this.totalTeam, this.budget, this.classrating);


    }
}



